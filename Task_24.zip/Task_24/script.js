$(document).ready(function(){	
	$('#check-btn').click(function(){
		let email=$('#email').val();
		if(email){
			$.ajax({
				url:'./Components/checkEmail.cfc?method=checkEmail',
				type:'POST',
				data:{email:email},				
				success:function(response){
						let data= JSON.parse(response);
						if(data.trim()==="Exists"){
							alert('Mail Id already Exists');
							$('#submit-btn').css('display',none);
						}
						else{
							alert(data);
							$('#submit-btn').prop('disabled',false);
						}	
					},
					error:function(){
						alert("An Error Occured");
					}	
			});
			
		}
		else{
			alert("Please enter an email Id");
		}			
	});
});