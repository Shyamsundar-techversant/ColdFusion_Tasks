USE coldfusion;
CREATE TABLE subscription(
	firstname VARCHAR(20),
    email VARCHAR(40)
);
