USE coldfusion;
CREATE TABLE docData(words VARCHAR(200));
SELECT * FROM docData;
